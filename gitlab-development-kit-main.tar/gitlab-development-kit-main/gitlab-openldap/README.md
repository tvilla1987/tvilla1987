This information [has moved](../doc/howto/ldap.md).
