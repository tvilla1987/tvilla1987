## Overview

<!-- Details of the issue.  Include any console output or screenshots. -->

## Steps to replicate (optional)

<!-- Clear steps of how to replicate the issue. -->

## Proposal (optional)

<!-- Description of any proposal you might have. -->

## Environment (optional)

- Operating system: macOS/Linux/etc
- The contents of your `gdk.yml`
- Ruby version: `<!-- output of `ruby --version` -->`
- GDK version: `<!-- output of `git rev-parse --short HEAD` -->`
