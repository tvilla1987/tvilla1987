This docker image is used as a Vagrant image for development of GitLab.
