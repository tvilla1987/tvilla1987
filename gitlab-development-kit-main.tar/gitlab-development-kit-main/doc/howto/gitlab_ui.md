# GitLab UI

If you wish to clone and keep an updated [GitLab UI](https://gitlab.com/gitlab-org/gitlab-ui/)
as part of your GDK, simply:

1. Add the following settings in your `gdk.yml`:

    ```yaml
    gitlab_ui:
      enabled: true
    ```

1. Run `gdk update`
