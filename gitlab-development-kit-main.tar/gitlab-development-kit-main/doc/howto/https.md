# HTTPS

To setup HTTPS with SSL/TLS, follow the steps for [setting up NGINX](nginx.md).
