# Enabling Git push options

To support Git [push options](https://docs.gitlab.com/ee/user/project/push_options.html)
with GDK, run the following command:

```shell
git config --global receive.advertisepushoptions true
```
