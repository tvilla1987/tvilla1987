# Start the Rails console

To start the Rails console in GDK:

```shell
cd <gdk-dir>/gitlab
bundle exec rails console
```

To exit the console, type: `quit` and press Enter.
