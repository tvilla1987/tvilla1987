# Prepare your system for GDK

Instructions for preparing your system for GDK have been moved to [`index.md`](index.md)
