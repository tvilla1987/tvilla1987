# frozen_string_literal: true

require_relative 'cop/avoid_time_new'
